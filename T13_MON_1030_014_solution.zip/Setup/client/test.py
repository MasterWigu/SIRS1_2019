def main():
	print("OLAOLA")
	return str(input())